const http = require("http");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers
} = require("@whiskeysockets/baileys");
const P = require("pino");
const qrcode = require("qrcode-terminal");
const config = require("./config");
const { handleMessage } = require("./handler");

const PORT = Number(process.env.PORT || 8000);
const PAIRING_NUMBER = (process.env.PAIRING_NUMBER || "").replace(/\D/g, "");

http.createServer((req, res) => {
  res.writeHead(200, {"Content-Type":"text/plain"});
  res.end(`${config.botName} is running\n`);
}).listen(PORT, "0.0.0.0", () => console.log(`Health server on ${PORT}`));

let starting = false;

async function startBot() {
  if (starting) return;
  starting = true;

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionFolder);
  let version;
  try { ({ version } = await fetchLatestBaileysVersion()); } catch {}

  const sock = makeWASocket({
    auth: state,
    version,
    logger: P({ level: "silent" }),
    printQRInTerminal: false,
    browser: Browsers.ubuntu(config.botName),
    markOnlineOnConnect: false
  });

  sock.ev.on("creds.update", saveCreds);

  if (!state.creds.registered && PAIRING_NUMBER) {
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(PAIRING_NUMBER);
        console.log("================================");
        console.log("SACHIYA MD PAIRING CODE:", code);
        console.log("WhatsApp > Linked devices > Link with phone number instead");
        console.log("================================");
      } catch (e) {
        console.error("Pairing code error:", e?.message || e);
      }
    }, 1500);
  }

  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr && !PAIRING_NUMBER && !state.creds.registered) {
      console.log("Scan this QR with WhatsApp > Linked devices:");
      qrcode.generate(qr, { small: true });
    }
    if (connection === "open") {
      starting = false;
      console.log(`${config.botName} connected successfully.`);
    }
    if (connection === "close") {
      starting = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) setTimeout(startBot, 3000);
      else console.log("Logged out.");
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    for (const msg of messages) {
      try { await handleMessage(sock, msg); }
      catch (e) { console.error("Message handler error:", e); }
    }
  });
}

startBot().catch(console.error);
