# Sachiya MD — Koyeb Ready

## Koyeb setup
1. Put this project in a GitHub repository.
2. Koyeb: Create Web Service → GitHub.
3. Select the repository and `main` branch.
4. Builder: **Buildpack**.
5. Run command: `npm start`.
6. Add environment variable:
   `PAIRING_NUMBER=94778936490`
7. Deploy.
8. Open **Runtime Logs** and copy the `SACHIYA MD PAIRING CODE`.
9. WhatsApp → Settings → Linked devices → Link a device → Link with phone number instead.

The app includes a small HTTP health server and uses Koyeb's PORT variable.
